"""
Flask API Server for IdeaFlow React Frontend
Provides REST endpoints for session management with PostgreSQL backend
"""

from flask import Flask, request, jsonify, send_from_directory, send_file
from flask_cors import CORS
from flask_socketio import SocketIO, emit, join_room, leave_room
from utils.postgres_db_manager import PostgresDBManager
from sqlalchemy import text
import uuid
from datetime import datetime
import os

# Create Flask app with static file serving
app = Flask(__name__, static_folder='ideaflow-react/dist', static_url_path='/')
# Allow all origins for development - in production this should be more restrictive
CORS(app, origins="*", 
     methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
     allow_headers=["Content-Type", "Authorization"])

# Initialize SocketIO
socketio = SocketIO(app, cors_allowed_origins="*")

# Use local PostgreSQL database
# DATABASE_URL is automatically set by the PostgreSQL service

# Initialize database manager
db_manager = PostgresDBManager()

# Background task to set up demo users after startup
import threading
import time

def setup_demo_users():
    """Background task to create demo users after server starts"""
    time.sleep(10)  # Wait for server to be fully ready
    
    users = [
        {"username": "facilitator", "password": "password123", "display_name": "Demo Facilitator"},
        {"username": "participant1", "password": "password123", "display_name": "Test Participant"},
    ]
    
    for user in users:
        try:
            user_id = db_manager.create_user(user["username"], user["password"], user["display_name"])
            if user_id:
                print(f"Created demo user: {user['username']}")
        except Exception as e:
            print(f"User {user['username']} may already exist")

# Start background setup in production
if os.getenv('REPLIT_DEPLOYMENT'):
    setup_thread = threading.Thread(target=setup_demo_users, daemon=True)
    setup_thread.start()

@app.route('/api/sessions', methods=['POST'])
def create_session():
    """Create a new ideation session"""
    try:
        data = request.get_json()
        facilitator_id = data.get('facilitator_id')
        title = data.get('title')
        description = data.get('description')
        max_participants = data.get('max_participants', 10)
        
        # Validate that the user is a facilitator (check if they have facilitator role)
        user = db_manager.authenticate_user_by_id(facilitator_id)
        if not user:
            return jsonify({'error': 'User not found'}), 404
            
        # Check if user is a known facilitator (username-based check)
        known_facilitators = ['f683d70f-2bd9-4622-89fa-3da0af573378', 'ffdb47f1-dfe8-4446-a266-ea2dbcd039da']  # facilitator, facilitator2
        is_facilitator = facilitator_id in known_facilitators or user['username'] in ['facilitator', 'facilitator2']
        
        if not is_facilitator:
            return jsonify({'error': 'Only facilitators can create sessions'}), 403
        
        session_data = {
            'id': str(uuid.uuid4()),
            'name': title,  # Map title to name column in database
            'question': description,  # Map description to question column in database
            'facilitator_id': facilitator_id,
            'max_participants': max_participants,
            'votes_per_participant': data.get('votes_per_participant', 5),
            'max_votes_per_idea': data.get('max_votes_per_idea', 3),
            'current_phase': 1,
            'status': 'active',
            'created_at': datetime.now().isoformat()
        }
        
        session_id = db_manager.create_session(session_data)
        session_data['id'] = session_id
        
        return jsonify(session_data), 201
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/facilitators/<facilitator_id>/sessions', methods=['GET'])
def get_facilitator_sessions(facilitator_id):
    """Get all sessions created by a specific facilitator"""
    try:
        sessions = db_manager.get_facilitator_sessions(facilitator_id)
        return jsonify(sessions), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/sessions/<session_id>', methods=['GET'])
def get_session(session_id):
    """Get session details by ID"""
    try:
        session = db_manager.get_session(session_id)
        if session:
            return jsonify({
                'id': session['id'],
                'name': session['name'],
                'question': session['question'],
                'facilitator_id': session['facilitator_id'],
                'facilitator_name': session.get('facilitator_name', ''),
                'current_phase': session['current_phase'],
                'max_participants': session['max_participants'],
                'votes_per_participant': session.get('votes_per_participant', 5),
                'max_votes_per_idea': session.get('max_votes_per_idea', 3),
                'status': session['status'],
                'created_at': session['created_at']
            })
        else:
            return jsonify({'error': 'Session not found'}), 404
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/sessions/<session_id>/participants', methods=['POST'])
def join_session(session_id):
    """Join a session as a participant"""
    try:
        data = request.get_json()
        user_name = data.get('user_name')  # This is the session join name, but we'll use registered name
        user_id = data.get('user_id', str(uuid.uuid4()))
        
        # Check if session exists
        session = db_manager.get_session(session_id)
        if not session:
            return jsonify({'error': 'Session not found'}), 404
        
        # Check if session is full
        participants = db_manager.get_participants(session_id)
        if len(participants) >= session['max_participants']:
            return jsonify({'error': 'Session is full'}), 400
        
        # Get the user's actual registered display name from their account
        user = db_manager.get_user_by_id(user_id)
        actual_name = user['display_name'] if user and user.get('display_name') else user_name
        
        # Add participant with their real registered name
        db_manager.add_participant(session_id, user_id, actual_name)
        
        participant_data = {
            'id': user_id,
            'name': actual_name,
            'session_id': session_id,
            'user_id': user_id,
            'joined_at': datetime.now().isoformat(),
            'status': 'active'
        }
        
        # Emit real-time update to all users in the session room
        socketio.emit('participant_joined', participant_data, room=f'session_{session_id}')
        
        return jsonify(participant_data), 201
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/sessions/<session_id>/participants', methods=['GET'])
def get_participants(session_id):
    """Get all participants for a session"""
    try:
        participants = db_manager.get_participants(session_id)
        return jsonify(participants)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/sessions/<session_id>/phase', methods=['PUT'])
def update_session_phase(session_id):
    """Update session phase"""
    try:
        data = request.get_json()
        new_phase = data.get('phase')
        
        # Clear votes when transitioning FROM voting phase (4) to any other phase
        # This ensures vote counts reset for new rounds
        if not db_manager.engine:
            return jsonify({'error': 'Database connection failed'}), 500
            
        with db_manager.engine.connect() as conn:
            # Get current phase
            current_query = text("SELECT current_phase FROM sessions WHERE id = :session_id")
            current_result = conn.execute(current_query, {'session_id': session_id})
            current_row = current_result.fetchone()
            current_phase = current_row[0] if current_row else 1
            
            # Never automatically clear votes during phase transitions
            # Votes should persist when moving between phases 4 and 5
            # This allows facilitators to go back and forth without losing voting data
            # Votes will only be cleared when starting a new iterative round
        
        db_manager.update_session_phase(session_id, new_phase)
        
        # Emit phase change to all participants
        socketio.emit('phase_changed', {'phase': new_phase}, room=f'session_{session_id}')
        
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/sessions/<session_id>/timer', methods=['POST'])
def start_timer(session_id):
    """Start or update session timer"""
    try:
        data = request.get_json()
        duration = data.get('duration', 300)  # Default 5 minutes
        action = data.get('action', 'start')  # start, pause, stop
        
        timer_data = {
            'duration': duration,
            'remaining': duration,
            'is_running': action == 'start',
            'started_at': datetime.now().isoformat() if action == 'start' else None
        }
        
        # Store timer state for synchronization
        session_timers[session_id] = timer_data
        
        # Emit timer update to all participants in session
        socketio.emit('timer_update', timer_data, room=f'session_{session_id}')
        
        return jsonify({'success': True, 'timer': timer_data})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/sessions/<session_id>/timer', methods=['PUT'])
def update_timer(session_id):
    """Update timer state (pause, resume, stop)"""
    try:
        data = request.get_json()
        remaining = data.get('remaining')
        is_running = data.get('is_running', False)
        
        timer_data = {
            'remaining': remaining,
            'is_running': is_running,
            'updated_at': datetime.now().isoformat()
        }
        
        # Update stored timer state
        if session_id in session_timers:
            session_timers[session_id].update(timer_data)
        else:
            session_timers[session_id] = timer_data
        
        # Emit timer update to all participants
        socketio.emit('timer_update', timer_data, room=f'session_{session_id}')
        
        return jsonify({'success': True, 'timer': timer_data})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# In-memory timer storage for simple coordination
session_timers = {}

@app.route('/api/sessions/<session_id>/timer-status', methods=['GET'])
def get_timer_status(session_id):
    """Get current timer status for synchronization"""
    try:
        timer_data = session_timers.get(session_id, {
            'remaining': 0,
            'is_running': False,
            'duration': 300
        })
        return jsonify(timer_data)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/sessions/<session_id>/voting-settings', methods=['PUT'])
def update_voting_settings(session_id):
    """Update voting configuration for a session"""
    try:
        data = request.get_json()
        max_votes_per_idea = data.get('max_votes_per_idea')
        votes_per_participant = data.get('votes_per_participant')
        
        if max_votes_per_idea is not None and (not isinstance(max_votes_per_idea, int) or max_votes_per_idea < 1 or max_votes_per_idea > 10):
            return jsonify({'error': 'Max votes per idea must be between 1 and 10'}), 400
            
        if votes_per_participant is not None and (not isinstance(votes_per_participant, int) or votes_per_participant < 1 or votes_per_participant > 50):
            return jsonify({'error': 'Votes per participant must be between 1 and 50'}), 400
        
        success = db_manager.update_voting_settings(session_id, max_votes_per_idea, votes_per_participant)
        if success:
            return jsonify({'success': True}), 200
        else:
            return jsonify({'error': 'Failed to update voting settings'}), 500
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/sessions/<session_id>/finish', methods=['POST'])
def finish_session(session_id):
    """Finish a session and archive it"""
    try:
        # Update session status to completed
        conn = db_manager.get_connection()
        if conn:
            with conn:
                conn.execute(text("""
                    UPDATE sessions 
                    SET status = 'completed', completed_at = :completed_at 
                    WHERE id = :session_id
                """), {"completed_at": datetime.now(), "session_id": session_id})
                conn.commit()
        
        return jsonify({'success': True, 'message': 'Session completed and archived'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/sessions/<session_id>/ideas', methods=['POST'])
def submit_idea(session_id):
    """Submit an idea to a session"""
    try:
        # Check if session is in idea submission phase (Phase 2 or iterative phases)
        session = db_manager.get_session(session_id)
        if not session:
            return jsonify({'error': 'Session not found'}), 404
            
        current_phase = session.get('current_phase', session.get('phase', 1))
        if current_phase not in [2, 5, 6]:  # Only allow in idea generation or iterative phases
            return jsonify({'error': f'Ideas can only be submitted during idea generation phases. Current phase: {current_phase}'}), 400
        
        data = request.get_json()
        print(f"Received idea data: {data}")
        
        # Extract content properly - handle both direct content and nested content
        content = data.get('content')
        if isinstance(content, dict):
            # If content is a dict, extract the actual content string
            actual_content = content.get('content', str(content))
            author_id = content.get('author_id')
            author_name = content.get('author_name')
        else:
            # Content is already a string
            actual_content = content
            author_id = data.get('author_id')
            author_name = data.get('author_name')
        
        # Force lookup of author name from database if not provided or is "Anonymous"
        if not author_name or author_name == 'Anonymous':
            if author_id:
                user = db_manager.authenticate_user_by_id(author_id)
                if user:
                    author_name = user.get('display_name') or user.get('username') or 'Anonymous'
                else:
                    author_name = 'Anonymous'
            else:
                author_name = 'Anonymous'
        
        idea_data = {
            'session_id': session_id,
            'content': actual_content,
            'author_id': author_id,
            'author_name': author_name
        }
        
        print(f"Processed idea data: {idea_data}")
        
        idea_id = db_manager.add_idea(idea_data)
        if idea_id:
            idea_data['id'] = idea_id
            idea_data['created_at'] = datetime.now().isoformat()
            
            # Emit real-time update to all users in the session room
            socketio.emit('idea_submitted', idea_data, room=f'session_{session_id}')
            
            return jsonify(idea_data), 201
        else:
            return jsonify({'error': 'Failed to create idea'}), 500
    except Exception as e:
        print(f"Error in submit_idea: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/sessions/<session_id>/ideas', methods=['GET'])
def get_ideas(session_id):
    """Get all ideas for a session"""
    try:
        # Check if this is a facilitator request (include_author parameter)
        include_author = request.args.get('include_author', 'false').lower() == 'true'
        
        # Get session info to check current phase and round
        session = db_manager.get_session(session_id)
        if not session:
            return jsonify({'error': 'Session not found'}), 404
        
        current_phase = session.get('current_phase', 1)
        current_round = session.get('round_number', 1)
        
        # For facilitators (include_author=true), show ALL ideas from all rounds in phase 3+
        # For participants, filter to current round only
        if include_author:
            # Facilitators always see ALL ideas for proper session management with author names
            ideas = db_manager.get_ideas(session_id, include_author=True, round_number=None)
        else:
            # Participants see only current round ideas for focused collaboration
            ideas = db_manager.get_ideas(session_id, include_author=False, round_number=current_round)
        
        # Map database field names to frontend expected format
        formatted_ideas = []
        for idea in ideas:
            formatted_idea = {
                'id': idea.get('id'),
                'content': idea.get('content'),
                'sessionId': session_id,
                'authorId': idea.get('author_id'),  # Map author_id to authorId
                'authorName': idea.get('author_name'),
                'createdAt': idea.get('created_at', ''),
                'themeId': idea.get('theme_id'),
                'roundNumber': idea.get('round_number', 1)
            }
            formatted_ideas.append(formatted_idea)
        
        return jsonify(formatted_ideas)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/users', methods=['POST'])
def create_user():
    """Register a new user"""
    try:
        data = request.get_json()
        username = data.get('username')
        password = data.get('password')
        display_name = data.get('display_name')
        
        user_id = db_manager.create_user(username, password, display_name)
        
        return jsonify({
            'id': user_id,
            'username': username,
            'display_name': display_name
        }), 201
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/auth/login', methods=['POST'])
def login():
    """Authenticate user login"""
    try:
        data = request.get_json()
        username = data.get('username')
        password = data.get('password')
        
        user = db_manager.authenticate_user(username, password)
        if user:
            return jsonify({
                'id': user['id'],
                'username': user['username'],
                'display_name': user['display_name']
            })
        else:
            return jsonify({'error': 'Invalid credentials'}), 401
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# WebSocket event handlers
@socketio.on('connect')
def handle_connect():
    """Handle client connection"""
    print('Client connected')

@socketio.on('disconnect')
def handle_disconnect():
    """Handle client disconnection"""
    print('Client disconnected')

@socketio.on('join_session')
def handle_join_session(data):
    """Join a session room for real-time updates"""
    session_id = data.get('session_id')
    if session_id:
        join_room(f'session_{session_id}')
        emit('joined_session', {'session_id': session_id})

@socketio.on('leave_session')
def handle_leave_session(data):
    """Leave a session room"""
    session_id = data.get('session_id')
    if session_id:
        leave_room(f'session_{session_id}')
        emit('left_session', {'session_id': session_id})

# Add voting endpoint
@app.route('/api/sessions/<session_id>/votes', methods=['POST'])
def submit_vote(session_id):
    """Submit or update votes for an idea"""
    try:
        data = request.get_json()
        idea_id = data.get('idea_id')
        voter_id = data.get('voter_id')
        voter_name = data.get('voter_name')
        vote_count = data.get('votes', 1)  # Total votes for this idea
        
        # Get session configuration
        session = db_manager.get_session(session_id)
        if not session:
            return jsonify({'error': 'Session not found'}), 404
            
        max_votes_per_idea = session.get('max_votes_per_idea', 3)
        votes_per_participant = session.get('votes_per_participant', 5)
        
        # Validate vote count for this idea
        if vote_count > max_votes_per_idea:
            return jsonify({'error': f'Maximum {max_votes_per_idea} votes allowed per idea'}), 400
            
        # Get existing votes for this user to check total limits  
        existing_votes = db_manager.get_votes(session_id, voter_id)
        # Sum points field to get actual vote counts
        current_idea_votes = sum(v.get('points', 0) for v in existing_votes if v.get('idea_id') == idea_id)
        other_votes = sum(v.get('points', 0) for v in existing_votes if v.get('idea_id') != idea_id)
        
        # Check if new total would exceed participant limit
        new_total = other_votes + vote_count
        if new_total > votes_per_participant:
            return jsonify({'error': f'You only have {votes_per_participant - other_votes} votes remaining'}), 400
        
        # Update or insert vote using upsert operation
        try:
            result = db_manager.upsert_vote({
                'session_id': session_id,
                'idea_id': idea_id,
                'voter_id': voter_id,
                'voter_name': voter_name,
                'votes': vote_count
            })
            
            if result:
                # Emit real-time update to all users in the session room
                socketio.emit('vote_updated', {
                    'session_id': session_id,
                    'idea_id': idea_id,
                    'voter_id': voter_id,
                    'votes': vote_count
                }, to=f'session_{session_id}')
                
                return jsonify({'success': True, 'votes': vote_count}), 201
            else:
                return jsonify({'error': 'Failed to submit vote'}), 500
        except Exception as db_error:
            print(f"Database error in vote submission: {db_error}")
            return jsonify({'error': f'Database error: {str(db_error)}'}), 500
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/sessions/<session_id>/votes', methods=['GET'])
def get_votes(session_id):
    """Get vote results for a session or specific user votes"""
    try:
        voter_id = request.args.get('voter_id')
        if voter_id:
            # Get votes for specific user and format for frontend
            votes = db_manager.get_votes(session_id, voter_id)
            # Convert to frontend format: array of objects with idea_id and votes count
            formatted_votes = []
            for vote in votes:
                formatted_votes.append({
                    'idea_id': vote.get('idea_id'),
                    'votes': vote.get('points', 1),  # Use points field as vote count
                    'voter_id': voter_id,
                    'session_id': session_id
                })
            return jsonify(formatted_votes)
        else:
            # Get aggregated vote results for all users
            vote_results = db_manager.get_vote_results(session_id)
            return jsonify(vote_results)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/sessions/<session_id>/iterative-prompt', methods=['POST'])
def create_iterative_prompt(session_id):
    """Create a new iterative brainstorming round with selected ideas as prompts"""
    try:
        data = request.get_json()
        selected_idea_ids = data.get('selected_idea_ids', [])
        facilitator_id = data.get('facilitator_id')
        
        if not selected_idea_ids:
            return jsonify({'error': 'No ideas selected'}), 400
            
        # Verify facilitator permissions
        session = db_manager.get_session(session_id)
        session_facilitator_id = session.get('facilitatorId') or session.get('facilitator_id')
        if not session or session_facilitator_id != facilitator_id:
            return jsonify({'error': 'Unauthorized'}), 403
            
        # Get the selected ideas content
        if not db_manager.engine:
            return jsonify({'error': 'Database connection failed'}), 500
        with db_manager.engine.connect() as conn:
            query = text("""
                SELECT id, content, author_id 
                FROM ideas 
                WHERE id = ANY(:idea_ids) AND session_id = :session_id
            """)
            result = conn.execute(query, {
                'idea_ids': selected_idea_ids,
                'session_id': session_id
            })
            selected_ideas = [dict(row._mapping) for row in result]
            
        if not selected_ideas:
            return jsonify({'error': 'Selected ideas not found'}), 404
            
        # Update session with iterative prompt data
        iterative_data = {
            'round_number': session.get('round_number', 1) + 1,
            'selected_ideas': selected_ideas,
            'prompt_type': 'iterative',
            'created_at': datetime.utcnow().isoformat()
        }
        
        if not db_manager.engine:
            return jsonify({'error': 'Database connection failed'}), 500
        with db_manager.engine.connect() as conn:
            # First ensure the columns exist
            try:
                conn.execute(text("ALTER TABLE sessions ADD COLUMN IF NOT EXISTS iterative_prompt TEXT"))
                conn.execute(text("ALTER TABLE sessions ADD COLUMN IF NOT EXISTS round_number INTEGER DEFAULT 1"))
                conn.commit()
            except:
                pass  # Columns already exist
            
            # Clear all votes when starting new iterative round
            delete_votes_query = text("DELETE FROM votes WHERE idea_id IN (SELECT id FROM ideas WHERE session_id = :session_id)")
            conn.execute(delete_votes_query, {'session_id': session_id})
            
            # Store iterative prompt data in session
            update_query = text("""
                UPDATE sessions 
                SET iterative_prompt = :iterative_data,
                    round_number = :round_number,
                    current_phase = 2
                WHERE id = :session_id
            """)
            conn.execute(update_query, {
                'iterative_data': str(iterative_data),  # Store as JSON string
                'round_number': iterative_data['round_number'],
                'session_id': session_id
            })
            conn.commit()
            
        return jsonify({
            'success': True,
            'message': f'Started new brainstorming round with {len(selected_ideas)} selected ideas',
            'round_number': iterative_data['round_number'],
            'selected_ideas': selected_ideas
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/sessions/<session_id>/iterative-prompt', methods=['GET'])
def get_iterative_prompt(session_id):
    """Get current iterative brainstorming prompts for participants"""
    try:
        session = db_manager.get_session(session_id)
        if not session:
            return jsonify({'error': 'Session not found'}), 404
            
        iterative_prompt = session.get('iterative_prompt')
        if not iterative_prompt:
            return jsonify({'prompts': [], 'round_number': 1})
            
        # Parse the iterative data
        import ast
        try:
            prompt_data = ast.literal_eval(iterative_prompt) if isinstance(iterative_prompt, str) else iterative_prompt
        except:
            prompt_data = {'selected_ideas': [], 'round_number': 1}
            
        return jsonify({
            'prompts': prompt_data.get('selected_ideas', []),
            'round_number': prompt_data.get('round_number', 1),
            'prompt_type': prompt_data.get('prompt_type', 'iterative')
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/sessions/<session_id>/themes', methods=['POST'])
def generate_themes(session_id):
    """Generate AI themes for a session"""
    try:
        # Get all ideas for the session using db_manager
        if not db_manager.engine:
            return jsonify({'error': 'Database connection failed'}), 500
            
        with db_manager.engine.connect() as conn:
            # Get current session to determine round number for filtering
            session_query = text("SELECT round_number FROM sessions WHERE id = :session_id")
            session_result = conn.execute(session_query, {'session_id': session_id})
            session_row = session_result.fetchone()
            current_round = session_row[0] if session_row else 1
            
            # Only get ideas from current round for theme analysis
            query = text("""
                SELECT id, content, author_name 
                FROM ideas 
                WHERE session_id = :session_id AND round_number = :round_number
            """)
            result = conn.execute(query, {'session_id': session_id, 'round_number': current_round})
            ideas_data = [dict(row._mapping) for row in result]
        
        if not ideas_data:
            return jsonify({'themes': [], 'idea_theme_mapping': {}})
        
        # Convert to format expected by AI processor
        ideas = [{'id': str(row['id']), 'content': row['content']} for row in ideas_data]
        
        # Import and use AI processor
        from utils.ai_processor import AIProcessor
        ai_processor = AIProcessor()
        
        # Generate themes
        theme_data = ai_processor.get_themes_from_ideas(ideas)
        
        # Store themes in database
        with db_manager.engine.connect() as conn:
            for theme in theme_data.get('themes', []):
                query = text("""
                    INSERT INTO themes (id, session_id, name, description)
                    VALUES (:id, :session_id, :name, :description)
                    ON CONFLICT (id) DO UPDATE SET
                    name = EXCLUDED.name,
                    description = EXCLUDED.description
                """)
                conn.execute(query, {
                    'id': theme['id'],
                    'session_id': session_id,
                    'name': theme['name'],
                    'description': theme['description']
                })
            
            # Update idea-theme mapping
            for idea_id, theme_id in theme_data.get('idea_theme_mapping', {}).items():
                query = text("""
                    UPDATE ideas SET theme_id = :theme_id WHERE id = :idea_id
                """)
                # Convert numpy types to Python types for PostgreSQL compatibility
                theme_id_str = str(theme_id) if hasattr(theme_id, 'item') else str(theme_id)
                conn.execute(query, {'theme_id': theme_id_str, 'idea_id': str(idea_id)})
            
            conn.commit()
        
        return jsonify(theme_data)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/sessions/<session_id>/themes', methods=['GET'])
def get_themes(session_id):
    """Get AI themes for a session"""
    try:
        if not db_manager.engine:
            return jsonify({'error': 'Database connection failed'}), 500
            
        with db_manager.engine.connect() as conn:
            # Get themes with counts
            query = text("""
                SELECT t.id, t.name, t.description,
                       COUNT(i.id) as idea_count,
                       COALESCE(SUM(COALESCE(v.points, 0)), 0) as total_votes
                FROM themes t
                LEFT JOIN ideas i ON t.id = i.theme_id
                LEFT JOIN votes v ON i.id = v.idea_id
                WHERE t.session_id = :session_id
                GROUP BY t.id, t.name, t.description
                ORDER BY total_votes DESC
            """)
            result = conn.execute(query, {'session_id': session_id})
            
            themes = []
            for row in result:
                themes.append({
                    'id': row[0],
                    'name': row[1],
                    'description': row[2],
                    'idea_count': row[3],
                    'total_votes': row[4]
                })
            
            # Get ideas by theme
            query = text("""
                SELECT i.id, i.content, i.author_name, i.theme_id,
                       COALESCE(SUM(v.points), 0) as votes
                FROM ideas i
                LEFT JOIN votes v ON i.id = v.idea_id
                WHERE i.session_id = :session_id AND i.theme_id IS NOT NULL
                GROUP BY i.id, i.content, i.author_name, i.theme_id
                ORDER BY i.theme_id, votes DESC
            """)
            result = conn.execute(query, {'session_id': session_id})
            
            ideas_by_theme = {}
            for row in result:
                theme_id = row[3]
                if theme_id not in ideas_by_theme:
                    ideas_by_theme[theme_id] = []
                ideas_by_theme[theme_id].append({
                    'id': row[0],
                    'content': row[1],
                    'author_name': row[2],
                    'votes': row[4]
                })
        
        return jsonify({
            'themes': themes,
            'ideas_by_theme': ideas_by_theme
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Serve React app for deployment
@app.route('/')
def serve_react_app():
    """Serve the React app's index.html"""
    try:
        return send_file('ideaflow-react/dist/index.html')
    except:
        # Fallback if build doesn't exist
        return jsonify({'message': 'IdeaFlow API Server', 'status': 'running'}), 200

@app.route('/<path:path>')
def serve_static_files(path):
    """Serve static files from React build"""
    try:
        return send_from_directory('ideaflow-react/dist', path)
    except:
        # For client-side routing, serve index.html for unknown routes
        try:
            return send_file('ideaflow-react/dist/index.html')
        except:
            return jsonify({'error': 'React build not found'}), 404

if __name__ == '__main__':
    # Auto-detect deployment vs development
    port = int(os.environ.get('PORT', 5000))  # Default to 5000 for deployment
    debug_mode = os.environ.get('FLASK_ENV') != 'production'
    
    # If running in development mode, use port 8000 to avoid conflicts
    if debug_mode and port == 5000:
        port = 8000
    
    socketio.run(app, host='0.0.0.0', port=port, debug=debug_mode, use_reloader=False, log_output=True)