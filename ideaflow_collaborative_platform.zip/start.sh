#!/bin/bash
# IdeaFlow Startup Script

echo "Starting IdeaFlow Collaborative Ideation Platform..."

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
fi

# Activate virtual environment
source venv/bin/activate

# Install dependencies
echo "Installing Python dependencies..."
pip install -r requirements.txt

# Download spaCy model
echo "Downloading spaCy English model..."
python -m spacy download en_core_web_sm

# Set database URL if not set
if [ -z "$DATABASE_URL" ]; then
    echo "Warning: DATABASE_URL not set. Please set your PostgreSQL connection string:"
    echo "export DATABASE_URL='postgresql://username:password@host:port/database'"
    echo ""
    echo "For development, you can use SQLite (not recommended for production):"
    echo "export DATABASE_URL='sqlite:///ideaflow.db'"
fi

# Start the application
echo "Starting IdeaFlow on http://localhost:5000"
python main.py
